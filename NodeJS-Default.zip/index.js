const Discord = require('discord.js');
const config = require('./config');

const bot = new Discord.Client({
    disableEveryone: true,
    disabledEvents: ['TYPING_START']
});

bot.login(config.token);